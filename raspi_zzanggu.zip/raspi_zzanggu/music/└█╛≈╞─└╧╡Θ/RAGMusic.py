class RAGMusic:
    pass
